﻿namespace EMS
{
    partial class userInfoForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Title = new System.Windows.Forms.Label();
            this.password = new System.Windows.Forms.Label();
            this.empId = new System.Windows.Forms.Label();
            this.phoneNum = new System.Windows.Forms.Label();
            this.email = new System.Windows.Forms.Label();
            this.ssn = new System.Windows.Forms.Label();
            this.dateOfB = new System.Windows.Forms.Label();
            this.zipCode = new System.Windows.Forms.Label();
            this.state = new System.Windows.Forms.Label();
            this.city = new System.Windows.Forms.Label();
            this.aptNum = new System.Windows.Forms.Label();
            this.address = new System.Windows.Forms.Label();
            this.lastName = new System.Windows.Forms.Label();
            this.middleName = new System.Windows.Forms.Label();
            this.firstName = new System.Windows.Forms.Label();
            this.buttonBack = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Title
            // 
            this.Title.AutoSize = true;
            this.Title.Font = new System.Drawing.Font("Corbel", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Title.ForeColor = System.Drawing.Color.RoyalBlue;
            this.Title.Location = new System.Drawing.Point(198, 27);
            this.Title.Name = "Title";
            this.Title.Size = new System.Drawing.Size(365, 45);
            this.Title.TabIndex = 35;
            this.Title.Text = "Employee Information";
            // 
            // password
            // 
            this.password.AutoSize = true;
            this.password.Font = new System.Drawing.Font("Corbel", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.password.ForeColor = System.Drawing.Color.DimGray;
            this.password.Location = new System.Drawing.Point(320, 347);
            this.password.Name = "password";
            this.password.Size = new System.Drawing.Size(96, 23);
            this.password.TabIndex = 49;
            this.password.Text = "Password:";
            // 
            // empId
            // 
            this.empId.AutoSize = true;
            this.empId.Font = new System.Drawing.Font("Corbel", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.empId.ForeColor = System.Drawing.Color.DimGray;
            this.empId.Location = new System.Drawing.Point(164, 347);
            this.empId.Name = "empId";
            this.empId.Size = new System.Drawing.Size(121, 23);
            this.empId.TabIndex = 48;
            this.empId.Text = "Employee ID:";
            // 
            // phoneNum
            // 
            this.phoneNum.AutoSize = true;
            this.phoneNum.Font = new System.Drawing.Font("Corbel", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneNum.ForeColor = System.Drawing.Color.Gray;
            this.phoneNum.Location = new System.Drawing.Point(558, 267);
            this.phoneNum.Name = "phoneNum";
            this.phoneNum.Size = new System.Drawing.Size(142, 23);
            this.phoneNum.TabIndex = 47;
            this.phoneNum.Text = "Phone Number:";
            // 
            // email
            // 
            this.email.AutoSize = true;
            this.email.Font = new System.Drawing.Font("Corbel", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.email.ForeColor = System.Drawing.Color.Gray;
            this.email.Location = new System.Drawing.Point(320, 267);
            this.email.Name = "email";
            this.email.Size = new System.Drawing.Size(63, 23);
            this.email.TabIndex = 46;
            this.email.Text = "Email:";
            // 
            // ssn
            // 
            this.ssn.AutoSize = true;
            this.ssn.Font = new System.Drawing.Font("Corbel", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ssn.ForeColor = System.Drawing.Color.Gray;
            this.ssn.Location = new System.Drawing.Point(92, 267);
            this.ssn.Name = "ssn";
            this.ssn.Size = new System.Drawing.Size(52, 23);
            this.ssn.TabIndex = 45;
            this.ssn.Text = "SSN:";
            // 
            // dateOfB
            // 
            this.dateOfB.AutoSize = true;
            this.dateOfB.Font = new System.Drawing.Font("Corbel", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateOfB.ForeColor = System.Drawing.Color.Gray;
            this.dateOfB.Location = new System.Drawing.Point(558, 196);
            this.dateOfB.Name = "dateOfB";
            this.dateOfB.Size = new System.Drawing.Size(123, 23);
            this.dateOfB.TabIndex = 44;
            this.dateOfB.Text = "Date of Birth:";
            // 
            // zipCode
            // 
            this.zipCode.AutoSize = true;
            this.zipCode.Font = new System.Drawing.Font("Corbel", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.zipCode.ForeColor = System.Drawing.Color.Gray;
            this.zipCode.Location = new System.Drawing.Point(558, 145);
            this.zipCode.Name = "zipCode";
            this.zipCode.Size = new System.Drawing.Size(88, 23);
            this.zipCode.TabIndex = 43;
            this.zipCode.Text = "Zip Code:";
            // 
            // state
            // 
            this.state.AutoSize = true;
            this.state.Font = new System.Drawing.Font("Corbel", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.state.ForeColor = System.Drawing.Color.Gray;
            this.state.Location = new System.Drawing.Point(558, 94);
            this.state.Name = "state";
            this.state.Size = new System.Drawing.Size(61, 23);
            this.state.TabIndex = 42;
            this.state.Text = "State:";
            // 
            // city
            // 
            this.city.AutoSize = true;
            this.city.Font = new System.Drawing.Font("Corbel", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.city.ForeColor = System.Drawing.Color.Gray;
            this.city.Location = new System.Drawing.Point(320, 196);
            this.city.Name = "city";
            this.city.Size = new System.Drawing.Size(49, 23);
            this.city.TabIndex = 41;
            this.city.Text = "City:";
            // 
            // aptNum
            // 
            this.aptNum.AutoSize = true;
            this.aptNum.Font = new System.Drawing.Font("Corbel", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.aptNum.ForeColor = System.Drawing.Color.Gray;
            this.aptNum.Location = new System.Drawing.Point(320, 145);
            this.aptNum.Name = "aptNum";
            this.aptNum.Size = new System.Drawing.Size(175, 23);
            this.aptNum.TabIndex = 40;
            this.aptNum.Text = "Apt Num (optional):";
            // 
            // address
            // 
            this.address.AutoSize = true;
            this.address.Font = new System.Drawing.Font("Corbel", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.address.ForeColor = System.Drawing.Color.Gray;
            this.address.Location = new System.Drawing.Point(320, 94);
            this.address.Name = "address";
            this.address.Size = new System.Drawing.Size(83, 23);
            this.address.TabIndex = 39;
            this.address.Text = "Address:";
            // 
            // lastName
            // 
            this.lastName.AutoSize = true;
            this.lastName.Font = new System.Drawing.Font("Corbel", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lastName.ForeColor = System.Drawing.Color.Gray;
            this.lastName.Location = new System.Drawing.Point(92, 196);
            this.lastName.Name = "lastName";
            this.lastName.Size = new System.Drawing.Size(105, 23);
            this.lastName.TabIndex = 38;
            this.lastName.Text = "Last Name:";
            // 
            // middleName
            // 
            this.middleName.AutoSize = true;
            this.middleName.Font = new System.Drawing.Font("Corbel", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.middleName.ForeColor = System.Drawing.Color.Gray;
            this.middleName.Location = new System.Drawing.Point(92, 145);
            this.middleName.Name = "middleName";
            this.middleName.Size = new System.Drawing.Size(128, 23);
            this.middleName.TabIndex = 37;
            this.middleName.Text = "Middle Name:";
            // 
            // firstName
            // 
            this.firstName.AutoSize = true;
            this.firstName.Font = new System.Drawing.Font("Corbel", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.firstName.ForeColor = System.Drawing.Color.Gray;
            this.firstName.Location = new System.Drawing.Point(92, 94);
            this.firstName.Name = "firstName";
            this.firstName.Size = new System.Drawing.Size(107, 23);
            this.firstName.TabIndex = 36;
            this.firstName.Text = "First Name:";
            // 
            // buttonBack
            // 
            this.buttonBack.BackColor = System.Drawing.Color.Pink;
            this.buttonBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.buttonBack.Font = new System.Drawing.Font("Corbel", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonBack.Location = new System.Drawing.Point(12, 9);
            this.buttonBack.Name = "buttonBack";
            this.buttonBack.Size = new System.Drawing.Size(89, 37);
            this.buttonBack.TabIndex = 50;
            this.buttonBack.Text = "Logout";
            this.buttonBack.UseVisualStyleBackColor = false;
            this.buttonBack.Click += new System.EventHandler(this.buttonBack_Click);
            // 
            // userInfoForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.AliceBlue;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.buttonBack);
            this.Controls.Add(this.password);
            this.Controls.Add(this.empId);
            this.Controls.Add(this.phoneNum);
            this.Controls.Add(this.email);
            this.Controls.Add(this.ssn);
            this.Controls.Add(this.dateOfB);
            this.Controls.Add(this.zipCode);
            this.Controls.Add(this.state);
            this.Controls.Add(this.city);
            this.Controls.Add(this.aptNum);
            this.Controls.Add(this.address);
            this.Controls.Add(this.lastName);
            this.Controls.Add(this.middleName);
            this.Controls.Add(this.firstName);
            this.Controls.Add(this.Title);
            this.Name = "userInfoForm";
            this.Opacity = 0.95D;
            this.ShowIcon = false;
            this.Text = "EMS";
            this.Load += new System.EventHandler(this.userInfoForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Title;
        private System.Windows.Forms.Label password;
        private System.Windows.Forms.Label empId;
        private System.Windows.Forms.Label phoneNum;
        private System.Windows.Forms.Label email;
        private System.Windows.Forms.Label ssn;
        private System.Windows.Forms.Label dateOfB;
        private System.Windows.Forms.Label zipCode;
        private System.Windows.Forms.Label state;
        private System.Windows.Forms.Label city;
        private System.Windows.Forms.Label aptNum;
        private System.Windows.Forms.Label address;
        private System.Windows.Forms.Label lastName;
        private System.Windows.Forms.Label middleName;
        private System.Windows.Forms.Label firstName;
        private System.Windows.Forms.Button buttonBack;
    }
}