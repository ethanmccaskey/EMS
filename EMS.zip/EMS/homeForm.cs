﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using System.Data.Common;
using System.Configuration;

namespace EMS
{
    public partial class EMS : Form
    {
        public EMS()
        {
            InitializeComponent();
        }

        private void registerButton_Click(object sender, EventArgs e)
        {
            registerForm form = new registerForm();
            form.Show();
            form.SetBounds(this.Location.X, this.Location.Y, this.Width, this.Height);
            this.Hide();
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            loginForm form = new loginForm();
            form.Show();
            form.SetBounds(this.Location.X, this.Location.Y, this.Width, this.Height);
            this.Hide();
        }

        private void admin_Click(object sender, EventArgs e)
        {
            adminCheckFourm form = new adminCheckFourm();
            form.Show();
        }

        private void EMS_Load(object sender, EventArgs e)
        {

        }
    }
}
