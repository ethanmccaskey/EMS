﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EMS
{
    public partial class userInfoForm : Form
    {
        public userInfoForm()
        {
            InitializeComponent();
        }

        public void userInfoForm_Load(object sender, EventArgs e)
        {
            empId.Text += " " + loginForm.logData[0];
            firstName.Text += " " + loginForm.logData[1];
            middleName.Text += " " + loginForm.logData[2];
            lastName.Text += " " + loginForm.logData[3];
            address.Text += " " + loginForm.logData[4];
            aptNum.Text += " " + loginForm.logData[5];
            city.Text += " " + loginForm.logData[6];
            state.Text += " " + loginForm.logData[7];
            zipCode.Text += " " + loginForm.logData[8];
            dateOfB.Text += " " + loginForm.logData[9];
            ssn.Text += " " + loginForm.logData[10];
            email.Text += " " + loginForm.logData[11];
            phoneNum.Text += " " + loginForm.logData[12];
            password.Text += " " + loginForm.logData[13];
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            loginForm form = new loginForm();
            form.Show();
            form.SetBounds(this.Location.X, this.Location.Y, this.Width, this.Height);
            this.Hide();
        }
    }
}