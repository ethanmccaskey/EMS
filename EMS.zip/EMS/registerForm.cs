﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace EMS
{
    public partial class registerForm : Form
    {
        public registerForm()
        {
            InitializeComponent();
        }

        private void registerForm_Load(object sender, EventArgs e)
        {

        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            EMS ems = new EMS();
            ems.Show();
            ems.SetBounds(this.Location.X, this.Location.Y, this.Width, this.Height);
            this.Hide();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            bool isEmpty = false;
            string[] textString = new string[30];
            int count = 0;
            foreach (Control c in this.Controls)
            {
                if (c is TextBox)
                {
                    TextBox textBox = c as TextBox;
                    if(textBox.Text == string.Empty)
                    {
                        isEmpty = true;
                        textString[count] = textBox.Name;
                        count++;
                    }
                }
            }
            if (isEmpty == true)
            {
                string result = string.Join(" ", textString);
                MessageBox.Show($"Please input {result}");
            }
            else
            {
                inputToDB();
            }
            isEmpty = false;
        }
        public void inputToDB ()
        {
            try
            {
                SqlCommand cmd;
                SqlConnection con;
                SqlDataAdapter da;
                con = new SqlConnection(@"C:\Users\Ethan\source\repos\Ethan McCaskey - EMS\EMS\Data\DB.mdf");
                con.Open();
                cmd = new SqlCommand("INSERT INTO Info (EmpId, firstName, lastName, middleName," +
                    " Address, AptNum, City, stateCode, zipCode, dateOfBirth, ssn, phoneNum," +
                    " password) VALUES (@EmpId, @firstName, @lastName, @middleName," +
                    " @Address, @AptNum, @City, @stateCode, @zipCode, @dateOfBirth, @ssn, @phoneNum," +
                    " @password)", con);
                cmd.Parameters.AddWithValue("@firstName", value: FirstName.Text);
                cmd.Parameters.AddWithValue("@middleName", value: MiddleName.Text);
                cmd.Parameters.AddWithValue("@lastName", value: LastName.Text);
                cmd.Parameters.AddWithValue("@Address", value: StreetAddress.Text);
                cmd.Parameters.AddWithValue("@AptNum", value: numericUpDown1.Text);
                cmd.Parameters.AddWithValue("@City", value: City.Text);
                cmd.Parameters.AddWithValue("@stateCode", value: State.Text);
                cmd.Parameters.AddWithValue("@zipCode", value: ZipCode.Text);
                cmd.Parameters.AddWithValue("@dateOfbirth", value: DateofBirth.Text);
                cmd.Parameters.AddWithValue("@ssn", value: PhoneNumber.Text);
                cmd.Parameters.AddWithValue("@email", value: Email.Text);
                cmd.Parameters.AddWithValue("@phoneNum", value: PhoneNumber.Text);
                cmd.Parameters.AddWithValue("@EmpID", value: EmpID.Text);
                cmd.Parameters.AddWithValue("@password", value: Password.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Account Created!");
                EMS ems = new EMS();
                ems.SetBounds(this.Location.X, this.Location.Y, this.Width, this.Height);
                ems.Show();
                this.Hide();
            }
            catch
            {
                MessageBox.Show("Incorrect data type!");
            }
        }
    }
}
