﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EMS
{
    public partial class adminCheckFourm : Form
    {
        public string[] adminData = new string[15];
        public bool adminCheck = false;
        public static bool loginSucessful = false;
        public adminCheckFourm()
        {
            InitializeComponent();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            SqlCommand cmd;
            SqlConnection con;
            con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Ethan\source\repos\EMS\Data\DB.mdf;Integrated Security=True");
            cmd = new SqlCommand("select * from Info where EmpID like @EmpID and password = @password;");
            DataSet ds = new DataSet();

            cmd.Parameters.AddWithValue("@EmpID", value: ID.Text);
            cmd.Parameters.AddWithValue("@password", value: Password.Text);
            cmd.Connection = con;
            con.Open();

            SqlDataReader da = cmd.ExecuteReader();
            while (da.Read())
            {
                Console.WriteLine(da.GetValue(14).ToString());
                if (da.GetValue(14).ToString() == "1")
                    adminCheck = true;
                else
                    adminCheck = false;
            }

            da.Close();
            SqlDataAdapter daa = new SqlDataAdapter(cmd);
            daa.Fill(ds);
            con.Close();
            //admin is 1 not 0
            //public bool loginSucessful = ((ds.Tables.Count > 0) && (ds.Tables[0].Rows.Count > 0) && adminCheck == true);

            loginSucessful = true; //so you can always log in to test stuff
            if (loginSucessful)
            {
                MessageBox.Show("You can always go thru this (just for testing so you can see, the code works)");
                adminForm form = new adminForm();
                EMS ems = new EMS();
                this.Hide();
                form.Show();
            }
            else
            {
                MessageBox.Show("Invalid username or password!");
            }
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
