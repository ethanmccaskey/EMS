﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;

namespace EMS
{
    public partial class loginForm : Form
    {
        public int isID;
        public string isPassword;
        public static string[] logData = new string[15];
        public loginForm()
        {
            InitializeComponent();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            SqlCommand cmd;
            SqlConnection con;
            con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\Ethan\source\repos\EMS\Data\DB.mdf;Integrated Security=True");
            cmd = new SqlCommand("select * from Info where EmpID like @EmpID and password = @password;");
            DataSet ds = new DataSet();

            cmd.Parameters.AddWithValue("@EmpID", value: ID.Text);
            cmd.Parameters.AddWithValue("@password", value: Password.Text);
            cmd.Connection = con;
            con.Open();

            //i learned sql last night like 12 hours ago this is some code i dont really know how i got working and could probably be hacked in seconds

            SqlDataReader da = cmd.ExecuteReader();
            while (da.Read())
            {
                for (int i = 0; i != logData.Length; i++)
                {
                    logData[i] = da.GetValue(i).ToString();
                    Console.WriteLine(logData[i]);
                }
            }

            da.Close();
            SqlDataAdapter daa = new SqlDataAdapter(cmd);
            daa.Fill(ds);
            con.Close();

            bool loginSucessful = ((ds.Tables.Count > 0) && (ds.Tables[0].Rows.Count > 0));

            if (loginSucessful)
            {
                userInfoForm form = new userInfoForm();
                form.Show();
                form.SetBounds(this.Location.X, this.Location.Y, this.Width, this.Height);
                this.Hide();
                
            }
            else
            {
                MessageBox.Show("Invalid username or password!");
            }

        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            EMS ems = new EMS();
            ems.Show();
            ems.SetBounds(this.Location.X, this.Location.Y, this.Width, this.Height);
            this.Hide();
        }

        private void loginForm_Load(object sender, EventArgs e)
        {

        }
    }
}
